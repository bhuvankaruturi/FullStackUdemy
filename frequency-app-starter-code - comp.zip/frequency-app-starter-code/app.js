// write your code here!
var prevValue = '', val = '';
var count = 0;
d3.select('form')
	.on('submit', (d => {
		d3.event.preventDefault();
		value = d3.selectAll('input')
					.property('value').toLowerCase();
		count = getCount(value);
		d3.select("#phrase")
			.text('Analysis of: ' + value);
		d3.select("#count")
			.text("new characters: " + count);
		d3.selectAll('input')
			.attr('value', '');		
		setDivs();
		prevValue = value;
	})
	);
	
var getCount = function(val){
	count = 0;
	val = val.split('');
	val.forEach(i => {
		if(!prevValue.includes(i)) count++;
	});
	return count;
}

var setDivs = function(){
	let valuesSet = new Set(value.split(''));
	let divs = d3.select('#letters')
				.selectAll('div')
				.data(Array.from(valuesSet), (d => d))
				.text(d => d)
				.classed('letter', true)
				.style('background-color', 'yellow')
				.style('width', '20px')
				.style('height', setHeight);
	divs.exit().remove();
	divs.enter().append('div')
				.text(d => d)
				.classed('letter', true)
				.style('background-color', 'yellow')
				.style('width', '20px')
				.style('height', setHeight)
				.merge(divs);
}

var setHeight = function(d) {
	let letterCount = 0;
	value.split('').forEach( val => {
			if(val === d) letterCount++;
		})	
		letterCount = letterCount * 20;
		return letterCount + 'px';
}